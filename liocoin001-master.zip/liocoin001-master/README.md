
Liocoin

Liocoin is a POW\PoS -based cryptocurrency.

Development process
===========================

SPECIFICATIONS



Scrypt
PoW/PoS

POW: 6000 blocks

PoS: Yearly Interest 100%

Min.Coin age: 8 hours

Max age: unlimited

RPC 8668 

P2P 8667

Node

66.228.54.158

103.227.177.7








